package tugas5;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Savepoint;
import javax.swing.*;
	
	/**
	 *
	 * @author sistem
	 */
public class Step3 extends JFrame {
    
    String nama, gender, agama;
    JLabel lnama = new JLabel();
    JLabel lgender = new JLabel();
    JLabel lagama = new JLabel();
    
    Step3(String nama, String gender, String agama) {
	setDefaultCloseOperation(3);
        setSize(350, 200);
        setLayout(null);

        add(lnama);
        add(lgender);
        add(lagama);	
        
        nama = nama;
	gender = gender;
	agama = agama;
	        
        lnama.setText("nama : "+nama);
        lgender.setText("gender : "+gender);
        lagama.setText("agama : "+agama);
	
        lnama.setBounds(10, 10, 300, 20);
        lgender.setBounds(10, 30, 200, 20);
        lagama.setBounds(10, 50, 200, 20);
	

	setVisible(true);
   }
}

