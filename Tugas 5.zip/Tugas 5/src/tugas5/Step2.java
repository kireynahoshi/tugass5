package tugas5;

import tugas5.Step3;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

	
	/**
	 *
	 * @author sistem
	 */
	

public class Step2 extends JFrame {

    String nama, gender, agama;
    final JTextField fnama = new JTextField(10);
    
    JLabel lnama = new JLabel("nama");
    JLabel lgender = new JLabel("gender");

    JRadioButton rblaki = new JRadioButton(" laki-Laki ");
    JRadioButton rbprmn = new JRadioButton("perempuan ");

    JLabel lagama = new JLabel("agama");
    String[] namaAgama = {"islam", "kristen", "katolik", "hindu", "buddha"};
    JComboBox cmbAgama = new JComboBox(namaAgama);
    
    JButton btnSave = new JButton("OK");
		
    public Step2() {
        setDefaultCloseOperation(3);
        setSize(350, 200);        
          
        ButtonGroup group = new ButtonGroup();
          group.add(rblaki);
          group.add(rbprmn);
          
          setLayout(null);
          add(lnama);
          add(fnama);
          add(lgender);
          add(rblaki);
          add(rbprmn);
          add(lagama);
          add(cmbAgama);
	  add(btnSave);
          
	   btnSave.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
                            if (fnama.getText().length() == 0) {
                                JOptionPane.showMessageDialog(null, "insert nama");
                            } 
                            else {
                                nama = fnama.getText();
                            }	

                            if (rblaki.isSelected()) {
                                gender = rblaki.getText();
                            } else if (rbprmn.isSelected()) {
                                gender = rbprmn.getText();
                            }
                           
                            agama = (String) cmbAgama.getSelectedItem();
	                
                        Step3 step3 = new Step3(nama, gender, agama);
                        
                        dispose();}
          });  
          lnama.setBounds(10, 10, 120, 20);
          fnama.setBounds(130, 10, 150, 20);
          lgender.setBounds(10, 35, 120, 20);
          rblaki.setBounds(130, 35, 100, 20);
          rbprmn.setBounds(230, 35, 100, 20);
          lagama.setBounds(10, 60, 150, 20);
          cmbAgama.setBounds(130, 60, 150, 20);
          btnSave.setBounds(100, 130, 120, 20);
          
          setVisible(true);
    }
}

