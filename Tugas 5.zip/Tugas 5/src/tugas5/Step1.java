package tugas5;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
	
	/**
	 *
	 * @author sistem
	 */
	public class Step1 {

	    /**
	     * @param args the command line arguments
	     */
	    public static void main(String[] args) {
	        // TODO code application logic here
	        new Login();
	    }
	

	}
	class Login extends JFrame {
	

	    JLabel username = new JLabel("username");
	    JLabel password = new JLabel("password");
	    JTextField user = new JTextField(20);
	    JTextField pass = new JTextField(20);
	    JButton login = new JButton("login");
	    JButton cancel = new JButton("cancel");
	

	    Login() {
	        setTitle("login");
	        setSize(350, 200);
	        setLayout(new FlowLayout());
	        setDefaultCloseOperation(EXIT_ON_CLOSE);

	        add(username);
	        add(user);
	        add(password);
	        add(pass);
	        add(login);
	        add(cancel);

	        login.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String username1 = user.getText();
                        String password1 = pass.getText();
                       
                        if (username1.equalsIgnoreCase("cwy") && password1.equalsIgnoreCase("pass123")) {
                            new Step2();
                        } else {
                            JOptionPane.showMessageDialog(null, "username atau password salah");
                        }
                    }
                });
	
	        setVisible(true);
	    }
	}

